<?php
session_start();
$login_id=$_POST['user_name'];
$password=$_POST['password'];
$security=$_POST['secur'];


$con=mysql_connect('localhost','root','');
if(!$con)
{
    print "Error".mysql_error();
}
$db=mysql_select_db('student_corner');
if(!$db){
 print "Error".mysql_error();   
 }
 
 
		$sql=mysql_query("SELECT * FROM `admin` WHERE  login_id='$login_id' and password='$password' and security='$security'");
		if($sql){
		$count=mysql_num_rows($sql);
		$id=mysql_fetch_array($sql);
		$_SESSION['aid']=$id['id'];
		if($count>0){
			print "<script>location.href='admin/request.php'</script>";
		}
		
		else{
			print "Not admin ";
		}
 
 }
 else{
 echo "sql error".mysql_error();
 }
 
 ?>