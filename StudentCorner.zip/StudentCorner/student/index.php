<?php session_start();?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title>    
    <style>#content{margin-top:200px;margin-left:50px;margin-bottom:50px;}
    #instruction h3{ float:right; margin-right:100px;padding-right:10px;}
    #name{
        float:right;
        padding-top:30px;
        
        color:#778899;
    }
    #menu ul li a{
        float:right;
        color:blue;
    }
     #content h2{
        float:left;
        position: relative;
        padding-top:0px;
        
     } 
     #course{
        padding-top:60px;
        padding-right:20px;
     }  
    
    #course ul li a{
        text-decoration:none;
        font-size: 20px;
        color: #778899;
        padding-top: 200px;
    }</style>
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="logout.php">
                       logout
                    </a>
                </li>
                
            </ul>
        </div>
        <div id="title">
             <div id="title4">
              student's corner
             </div>
             <div id="title2">
               Admin Panel
            </div>
            <div id="title3">
                </br>
                </div>
                <div id='date'>
                </br>
                </div>
                <div id="title5">
                Student's request
            </div>
        </div>
        <div id="content">
      <div id="instruction">  <h3>Instruction</h3></div></br><div id="name"><p align=right></p>please select a course name</p></div>
          <h2>Course Name</h2>
          <div id="course">
          <ul type='disc'>
		  <li><a href='c1/index.php'>Course 1</a></li>
		  <li><a href='c1/index.php'>Course 2</a></li>
		  <li><a href='c1/index.php'>Course 3</a></li>
		  <li><a href='c1/index.php'>Course 4</a></li>
          <ul>
          
        </div>
        </div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>