<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title>    
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="index.php">
                        HOME
                    </a>
                </li>
                <li>
                    <a href="lecture_materials.php">
                    LECTURE MATERIALS
                    </a>
                </li>
               
                <li>
                    <a href="reference_book.php">
                        REFERENCE BOOK
                    </a>
                </li>
                <li>
                    <a href="change_password.php">
                        CHANGE PASSWORD
                    </a>
                </li>
            </ul>
        </div>
        <div id="title">
             <div id="title4">
                    Student's corner
             </div>
        </div>
        <div id="body">
		<div id="pic"><img src="User Group-48.png" style="margin-left:auto;margin-right:auto;display:block;margin-top:40px;"></div>
            <div id="title2">
               Student's Panel
            </div>
            <div id="title3">
                </br>
                </div>
                <div id='date'>
                <script lang="javascript">
                var today=new Date();
                document.write(today);
                </script></br>
                </div>
                
            <div id="log">
            <div id="message">
            Not yet content here
            </div>
                
            </div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>