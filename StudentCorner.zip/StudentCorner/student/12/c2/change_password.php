<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title>    
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="index.php">
                        HOME
                    </a>
                </li>
                <li>
                    <a href="lecture_materials.php">
                    LECTURE MATERIALS
                    </a>
                </li>
                
                <li>
                    <a href="reference_book.php">
                        REFERENCE BOOK
                    </a>
                </li>
                <li>
                    <a href="contact.php">
                        CONTACT
                    </a>
                </li>
            </ul>
        </div>
        <div id="title">
             <div id="title4">
                    Student's corner
             </div>
        </div>
        <div id="body">
            <div id="title2">
               Student's Corner
            </div>
            <div id="title3">
                </br>
                </div>
                <div id='date'>
                <script lang="javascript">
                var today=new Date();
                document.write(today);
                </script></br>
                </div>
                <div id="title5">
                Change Password
            </div>
            <div id="log">
                <form method="post" action="change_password_process.php">
                <table border='0' cellspacing='0' cellpadding='11' align='center'>
                    <tr>
                        <td>
                        Roll
                        </td>
                        <td>
                            <input type="text" placeholder="username" name="roll" required/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                           Old Password:
                        </td>
                        <td>
                            <input type="password" placeholder="type your password" name="old_password" required/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            New password
                        </td>
                        <td>
                            <input type="text" placeholder="new_password" name="new_password" required/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                        </td>
                        <td>
                        </td>
                        <td>
                            <input type="submit"value='change' name="submit"/>
                        </td>
                    </tr>
                </table>
                </form>
            </div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>