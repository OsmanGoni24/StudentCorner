<?php session_start()?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title>    
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="index.php">
                        HOME
                    </a>
                </li>
                
                <li>
                    <a href="reference_book.php">
                        REFERENCE BOOK
                    </a>
                </li>
                <li>
                    <a href="contact.php">
                        CONTACT
                    </a>
                </li>
				<li>
                    <a href="change_password.php">
                        CHANGE PASSWORD
                    </a>
                </li>
            </ul>
        </div>
        <div id="title">
             <div id="title4">
                    Student's corner
             </div>
        </div>
		
        <div id="body">
		<div id="pic"><img src="User Group-48.png" style="margin-left:auto;margin-right:auto;display:block;margin-top:40px;"></div>
            <div id="title2">
               Student's Panel
            </div>
            <div id="title3">
                </br>
                </div>
                <div id='date'>
                <script lang="javascript">
                var today=new Date();
                document.write(today);
                </script></br>
                </div>
                
            <div id="log">
        <?php
        $con=mysql_connect('localhost','root','');
        if(!$con)
        {
            echo "connection error".mysql_error();
        }
          $db=mysql_select_db('student_corner') ;
          if(!$db) 
          {
            echo "database selection error".mysql_error();
          }
          $session=$_POST['session'];
          $sql=mysql_query('select file from uploadfile where session=$session');
          echo "<table>";
          while($data=mysql_fetch_array($sql))
          {
            echo "<tr>";
          echo "<td>";echo $file=$data['file'];echo "</td>";
          echo "<td>";?><a href="<?php echo $data[file];?>">Download</a><?php echo "</td>";
          echo '</br>';
          echo "</tr>";
          }
           ?>   
            </div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>