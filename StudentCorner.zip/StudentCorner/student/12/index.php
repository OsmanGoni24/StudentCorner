<?php session_start();
if(!isset($_SESSION['sid'])){
echo "<script>location.href='../../index.php'></script>";
}
else{
echo "";
}
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title>    
    <style>#content{margin-top:50px;margin-left:50px;margin-bottom:50px;height:300px;font-family:arial;}
    #instruction h3{ float:right; margin-right:100px;padding-right:10px;}
    #name{
        float:right;
        padding-top:30px;
        
        color:#778899;
    }
    #menu ul li a{
        text-align:right;
        color:#ffebcd;
    }
     
	 #instruction{
	 float:right;
	 margin-right:160px;
	 }
	 #instruction p{
	 color:#778899;
	 }
     #course{
	    float:left;
        padding-top:60px;
        padding-right:20px;
		margin-left:130px;
     }  
    
    #course h3 a{
        text-decoration:none;
        font-size: 20px;
        color: #778899;

    }</style>
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="logout.php">
                      LOGOUT
                    </a>
                </li>
                
            </ul>
        </div>
        <div id="title">
             <div id="title4">
              student's corner
             </div>
	    </div>
			 <img src="User Group-48.png"style="margin-left:auto;margin-right: auto;display: block;">
    

             <div id="title2">
               Student Panel
            </div>
            <div id="title3">
                </br>
                </div>
                <div id='date'>
                <script lang="javascript">
                var today=new Date();
                document.write(today);
                </script>
                </div>
                <div id="title5">
                
            </div>
        
        <div id="content">
     
          <div id="course">
		  <h2>Course Name</h2>
		  
		  <h3>&raquo;  &raquo; <a href='c2/index.php?course=11course1i'> Course 1</a></h3>
		  <h3>&raquo;  &raquo; <a href='c2/index.php?course=11course1g'> Course 2</a></h3>
          <h3>&raquo;  &raquo; <a href='c2/index.php?course=11course1'> Course 3</a></h3>
		  <h3>&raquo;  &raquo; <a href='c2/index.php?course=11course1r'> Course 4</a></h3>
          </div>
		 <div id="instruction">  <h3>Instruction</h3>
          
     <p>please select a course name</p></div>
          
        </div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>