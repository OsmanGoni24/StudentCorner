

<?php

if(isset($_SESSION['sid'])){
	unset($_SESSION['sid']);
	session_destroy();
	echo "<script>location.href='../../../index.php'</script>";

}
echo "<script>location.href='../../../index.php'</script>";



?>