<?php
$roll=$_POST[roll];
$old_password=$_POST[old_password];
$new_password=$_POST[new_password];
$approve=1;
$con=mysql_connect('localhost','root','');
if(!$con){
    echo 'error'.mysql_error();
}
$db=mysql_select_db('student_corner');
if(!$db){
    echo "database selection error".mysql_error();
}
$sql=mysql_query("update student set password=$new_password where roll=$roll and approve=$approve");
if($sql){
  header("Location:change_password1.php");  
}
else{
    header('Location:change_password2.php');
}

?>