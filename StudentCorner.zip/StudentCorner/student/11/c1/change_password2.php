<?php
session_start();
if(!isset($_SESSION['sid'])){
echo "<script>location.href='../../../index.php'></script>";
}
else{
echo "";
}
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title>
    <style>#message p{color:red;}
#message{width:400px;
text-align:center;margin-top:30px;
}</style>
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="change_password.php">
                        BACK
                    </a>
                </li>
            
            </ul>
        </div>
        <div id="header">
             <div id="title">
                    Student's corner
             </div>
        </div>
        <div id="body">
            <div id="title2">
               Student's Corner
            </div>
            <div id="title3">
                </br>
                </div>
                <div id='date'>
                <script lang="javascript">
                var today=new Date();
                document.write(today);
                </script></br>
                </div>
                <div id="title5">
                Change Password
            </div>
            <div id="message">
            <p>Your password has not been changed </p>
                
            </div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>