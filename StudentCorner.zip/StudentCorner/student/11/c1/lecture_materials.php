<?php session_start();
if(!isset($_SESSION['sid'])){
echo "<script>location.href='../../../index.php'></script>";
}
else{
echo "";
}
	if(isset($_SESSION['select_course'])){
	$_SESSION['select_course']=$_GET['course'];
		$course_table=$_SESSION['select_course'];
	}
	else{
	
	print " Not created any session";
	}
	
	
	?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title>
<style>
#log{
height:500px;
}
#dl a {
text-decoration:none;
color:#778899;
}
td{
border:1px solid #000;
margin-right:30px;
box-shadow:3px 3px 3px;
border-radius:8px;
}
</style>    
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="index.php?course=11course1i">
                        HOME
                    </a>
                </li>
				<li>
                    <a href="lecture_materials.php?course=11course1l">
                        LECTURE MATERIALS
                    </a>
                </li>
             
                <li>
                    <a href="reference_book.php?course=11course1r">
                        REFERENCE BOOK
                    </a>
                </li>
                <li>
                    <a href="contact.php">
                        CONTACT
                    </a>
                </li>
				<li>
                    <a href="change_password.php">
                        CHANGE PASSWORD
                    </a>
                </li>
				<li><a href='logout.php'>LOGOUT</a>
				</li>
            </ul>
        </div>
        <div id="header">
             <div id="title">
                    Student's corner
             </div>
        </div>
		
        <div id="body">
		<div id="pic"><img src="User Group-48.png" style="margin-left:auto;margin-right:auto;display:block;margin-top:40px;"></div>
            <div id="title2">
               Student's Panel
            </div>
            <div id="title3">
                </br>
                </div>
                <div id='date'>
                <script lang="javascript">
                var today=new Date();
                document.write(today);
                </script></br>
                </div>
                
            <div id="log">
			<div id="title5">
                Lecture materials
                </div>
         <?php  
			mysql_connect("localhost","root","");
			mysql_select_db("student_corner");
				$sql=mysql_query("select * from $course_table order by id desc");
				
				$count=mysql_num_rows($sql);
				if($count==0){
					print " No posted found";
				}
				
			else{
			$i=1;
			echo "<table border='0' align='center' width='700' cellspacing=10px>";
				while($row=mysql_fetch_array($sql)){
				   $up=$row['file1'];
					$time=$row['time'];
					$date=$row['date'];
					$class=$row['class'];
					
				  if($i==1){
				  echo "<tr>";
				  }
					//$msg=$row['messages'];
			

					//echo "<h1>class".$class."</h1>";
					//echo "$date $time";
				
					print "<td><div id=dl><a type='application/octet-stream' download='../../../$up' href='../../../$up'><h1>class".$class."</h1></a></div></td>";
					 
					if($i==2){
					$i=1;
					echo "</tr>";
					}
					else{
					$i++;
					}
				
					
                  
				}
			
			echo "</table>";
			}
			?>
            </div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>