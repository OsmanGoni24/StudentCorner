<?php
session_start();
if(!isset($_SESSION['sid'])){
echo "<script>location.href='../../../index.php'></script>";
}
else{
echo "";
}
if(isset($_SESSION['select_course'])){
        $_SESSION['select_course']=$_GET['course'];
		$course_table=$_SESSION['select_course'];
	}
	else{
	
	print " Not created any session";
	}
	?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title> 
<style>
#message{
height:200px;
}
#dl a {
text-decoration:underline;
color:blue;
}
</style>	
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="index.php?course=11course1i">
                        HOME
                    </a>
                </li>
                <li>
                    <a href="lecture_materials.php?course=11course1l">
                    LECTURE MATERIALS
                    </a>
                </li>
				<li>
                    <a href="grade_shit.php?course=11course1g">
                    GRADE SHEET
                    </a>
                </li>
                <li>
                    <a href="reference_book.php?course=11course1r">
                        REFERENCE BOOK
                    </a>
                </li>
                <li>
                    <a href="contact.php">
                        CONTACT
                    </a>
                </li>
				<li>
                    <a href="change_password.php">
                        CHANGE PASSWORD
                    </a>
                </li>
				<li>
                    <a href="logout.php">
                        LOGOUT
                    </a>
                </li>
            </ul>
        </div>
        <div id="header">
             <div id="title">
                    Student's corner
             </div>
        </div>
        <div id="body">
		<div id="pic"><img src="User Group-48.png" style="margin-left:auto;margin-right:auto;display:block;margin-top:40px;"></div>
            <div id="title2">
               Student's Panel
            </div>
            <div id="title3">
                </br>
                </div>
                <div id='date'>
                <script lang="javascript">
                var today=new Date();
                document.write(today);
                </script></br>
                </div>
                <div id="title5">
                Grade sheet
                </div>
				
            <div id="log">
            
           <?php  
			mysql_connect("localhost","root","");
			mysql_select_db("student_corner");
				$sql=mysql_query("select * from $course_table order by id desc");
				
				$count=mysql_num_rows($sql);
				if($count==0){
					print " No posted found";
				}
				
			else{
			
			
				while($row=mysql_fetch_array($sql)){
				   $up=$row['file2'];
					$time=$row['time'];
					$date=$row['date'];
					$class=$row['class'];
					$exam=$row['exam'];
				  
				  echo "<div id='message'>";
				  echo "<div id='date_time'>$date $time</div> ";
				 
				  echo "<div id='dl'> <a type='application/octet-stream' download='../../../$up' href='../../../$up'><h1>".$exam."</h1></a></div>";
				  echo "</div>";
                   echo "</br>";
                  }
                  echo "</br>";
                  echo "</br>";
                  }
				
					
			?>
         
                
            </div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>