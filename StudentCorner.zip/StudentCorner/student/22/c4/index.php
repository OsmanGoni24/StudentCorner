<?php session_start();
//$seesion=$_SESSION['session'];
if(!isset($_SESSION['sid'])){
echo "<script>location.href='../../../index.php'></script>";
}
else{
echo "";
}
?><!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title>
    <style>
	

	
	
	
	</style>
	   
</head>

<body>



    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="index.php">
                        HOME
                    </a>
                </li>
                <li>
                    <a href="lecture_materials.php?course=11course1l">
                        LECTURE MATERIALS
                    </a>
                </li>
               
                <li>
                    <a href="reference_book.php?course=11course1r">
                        REFERENCE BOOK
                    </a>
                </li>
                <li>
                    <a href="contact.php">
                        CONTACT
                    </a>
                </li>
			
				
            
				<li>
                    <a href="change_password.php">
                        CHANGE PASSWORD
                    </a>
					<li><a href='logout.php'>LOGOUT</a></li>
                
            </ul>
        </div>
        <div id="header">
             <div id="title">
                    Student's corner
             </div>
        </div>
        <div id="pic"><img src="User Group-48.png" style="margin-left:auto;margin-right:auto;display:block;margin-top:40px;"></div>
        <div id="body">
            <div id="title2">
               Student's Panel
            </div>
            <div id="title3">
                </br>
                </div>
                <div id='date'>
                <script lang="javascript">
                var today=new Date();
                document.write(today);
                </script></br>
                </div>
                
            
         
			
			<?php
	if($_GET){
		//$course=$_GET['course'];
		$_SESSION['select_course']=$_GET['course'];
	//	print $course;
	$course_table=$_SESSION['select_course'];
	}
else{
	$course_table=$_SESSION['select_course'];
}
              
			mysql_connect("localhost","root","");
			mysql_select_db("student_corner");
				$sql=mysql_query("select * from $course_table order by id desc");
				
				$count=mysql_num_rows($sql);
				if($count==0){
					print " No posted found";
				}
			else{
				while($row=mysql_fetch_array($sql)){
					$msg=$row['messages'];
					$class=$row['class'];
					$time=$row['time'];
					$date=$row['date'];
					echo "<div id='message'>";
					
					echo "<h1>class"." ".$class."</h1>";
				 
					
					
				
					echo "<div id='date_time'>$date $time</div> ";
					print "<div id='msg'>$msg</div>";
					echo "</div>";
					echo "</br>";
					echo "</br>";
				
				
				
				
				}
			
			
			}
			?>
            
                
            
			</div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>