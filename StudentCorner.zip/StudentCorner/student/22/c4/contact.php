<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title> 
<style>
#class_teacher{
float:left;
margin-left:100px;

}
#class_teacher h1{
font-family:arial;
color:#383838;
}
#class_monitor{
float:right;
margin-right:100px;
}
#class_monitor h1{
font-family:arial;
color:#383838;
}
#class_teacher p{
font-family:arial;
color:#778899;
font-weight:bold;
}
#class_teacher p a{
text-decoration:none;
}

#class_monitor p{
font-family:arial;
color:#778899;
font-weight:bold;
}
#container{
height:300px;
}
</style>	
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="index.php?course=11course1i">
                        HOME
                    </a>
                </li>
                <li>
                    <a href="lecture_materials.php?course=11course1l">
                    LECTURE MATERIALS
                    </a>
                </li>
                
                <li>
                    <a href="reference_book.php?course=11course1r">
                        REFERENCE BOOK
                    </a>
                </li>
				<li>
                    <a href="contact.php">
                        CONTACT
                    </a>
                </li>
                <li>
                    <a href="change_password.php">
                        CHANGE PASSWORD
                    </a>
                </li>
				<li>
                    <a href="logout.php">
                      LOGOUT
                    </a>
                </li>
            </ul>
        </div>
        <div id="header">
             <div id="title">
                    Student's corner
             </div>
        </div>
        
		<div id="pic"><img src="User Group-48.png" style="margin-left:auto;margin-right:auto;display:block;margin-top:40px;"></div>
            <div id="title2">
               Student's Panel
            </div>
            <div id="title3">
                </br>
                </div>
                <div id='date'>
                <script lang="javascript">
                var today=new Date();
                document.write(today);
                </script></br>
                </div>
                
           
            <div id='container'>
            <div id='class_teacher'>
			<h1> Class Teacher</h1>
			</br>
			</br>
			<p>Partha chakraborty</br>
			Lecturer</br>
			Department of Computer Science and Engineering</br>
			Comilla University</br>Coatbari,Comilla</br>Website<a href=www.parthobd.com>www.parthobd.com</a></br>Email:partho@parthobd.com
			</p>
            </div>
              <div id='class_monitor'>
			  <h1>Class Monitor</h1>
			  </br></br>
			  <p>1.Name:Abu Musa</br>
			     Mobile:01829652809</br></br>
              </div>			  
           </div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>