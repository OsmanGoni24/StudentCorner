<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title>  
    <style>
    
	#container{
	height:400px;
	}
    </style>  
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="index.php">
                        LOGIN
                    </a>
                </li>
                <li>
                    <a href="registration.php">
                        REGISTRATION
                    </a>
                </li>
            </ul>
        </div>
        <div id="header">
             <div id="title">
                    Student's corner
             </div>
        </div>
        <img src="capture3.PNG" style="margin-left: auto;margin-right: auto;display:block;">
        <div id="body">
            <div id="title2">
               Instruction</br>
            </div>
            <div id="slogan">
                </br>
            </div>
            <div id='date'>
                <script lang="javascript">
                    var today=new Date();
                    document.write(today);
                </script></br>
            </div>
            <div id="container">
            <div id="left_bar">
                <h2>New student</h2>
                <p>
                &nbsp;&nbsp;&nbsp;&nbsp;Go to Registration form</br>
                input login ID(i.e.your user ID)</br>
                &nbsp;Login Password(i.e. your login </br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;password)</br>
                &nbsp;&nbsp;&nbsp;&nbsp;Name(i.e your Full Name)</br>
                Roll number (i.e. your class Roll</br> 
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;number)</br>
                &nbsp;&nbsp;&nbsp;&nbsp;Email Address(i.e. Your Email Address)</br>
                &nbsp;&nbsp;&nbsp;Mobile Number(i.e your mobile</br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;number)</br>
                Semester Code(i.e11=1st Year 1st</br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Semester)</br>
                </p>
            </div>
            <div id="right_bar">
                <h2>Registered Student</h2></br></br></br><p>goto login form and fillup</br>login id login password and</br>semester code</p>
            </div>
        </div>    
        <div id="footer">
            <div id="copy">
            
            
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>