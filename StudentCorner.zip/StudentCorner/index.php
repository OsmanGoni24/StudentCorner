<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title>   
    <style>
    #log select{
      border-left-color: #778899;
    border-top-color: #778899;
    width:190px;
    height:30px;
    text-align: center;  
    }
	
    </style> 
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="index.php">
                        HOME
                    </a>
                </li>
                <li>
                    <a href="registration.php">
                        REGISTRATION
                    </a>
                </li>
                <li>
                    <a href="instruction.php">
                        INSTRUCTION
                    </a>
                </li>
				<li>
                    <a href="admin.php">
                        ADMIN
                    </a>
                </li>
            </ul>
        </div>
		
        <div id="header">
             <div id="title">
                    
             </div>
        </div>
		
        <img src='capture3.PNG'style="margin-left:auto;margin-right:auto;display:block;margin-top:40px;">
        <div id="body">
            <div id="title2">
               Student's Corner
            </div>
            <div id="slogan">
                </br>
                </div>
                <div id='date'>
                <script lang="javascript">
                var today=new Date();
                document.write(today);
                </script></br>
                </div>
                </div>
                
			<div id='content'>
			<div id="title6">
                Student login panel
            </div>
            <div id="log">
                <form method="post" action="student_login.php">
                <table border='0' cellspacing='0' cellpadding='11' align='center'>
                    <tr>
                        <td>
                            Login ID:
                        </td>
                        <td>
                            <input type="text" placeholder="username" name="user_name" required/>
                        </td>
                    </tr>
                  
                    <tr>
                        <td>
                            Password:
                        </td>
                        <td>
                            <input type="password" placeholder="type your password" name="password" required/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Semester:
                        </td>
                        <td>
                            <input type="text" placeholder="semester code" name="semester"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
						</td>
						
                        
                        <td align='right'>
                            <input type="submit"value='Login' name="submit"/>
                        </td>
                    </tr>
                </table>
                </form>
            </div>
        </div>
		</div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>