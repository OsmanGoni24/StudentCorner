-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 07, 2018 at 04:44 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `student_corner`
--

-- --------------------------------------------------------

--
-- Table structure for table `11course1`
--

CREATE TABLE IF NOT EXISTS `11course1` (
`id` int(11) NOT NULL,
  `time` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `class` int(5) NOT NULL,
  `messages` longtext,
  `file` varchar(500) DEFAULT NULL,
  `file2` varchar(500) DEFAULT NULL,
  `messages2` longtext
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `11course1`
--

INSERT INTO `11course1` (`id`, `time`, `date`, `class`, `messages`, `file`, `file2`, `messages2`) VALUES
(13, '18:00 PM', '16-02-07', 1, 'your next class will be held on next monday', 'uploads/-785845275Lecture 5 (Scanner).ppt', 'uploads/Lecture 2 (Mouse) - Copy.ppt', 'teach yourself by herbart schildt'),
(14, '12:23 PM', '16-02-08', 2, 'your class will be held on tomorrow 3.00 pm', 'uploads/-119476506Lecture 1 (Keyboard).ppt', 'uploads/Lecture 1 (Keyboard).ppt', '');

-- --------------------------------------------------------

--
-- Table structure for table `11course1g`
--

CREATE TABLE IF NOT EXISTS `11course1g` (
`id` int(11) NOT NULL,
  `time` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `class` int(11) NOT NULL,
  `file2` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `11course1g`
--

INSERT INTO `11course1g` (`id`, `time`, `date`, `class`, `file2`) VALUES
(5, '15:46 PM', '16-02-09', 8, 'uploads/-1170477420table.docx'),
(6, '12:19 PM', '16-02-10', 5, 'uploads/-1046563749table.docx');

-- --------------------------------------------------------

--
-- Table structure for table `11course1i`
--

CREATE TABLE IF NOT EXISTS `11course1i` (
`id` int(11) NOT NULL,
  `time` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `class` int(11) NOT NULL,
  `messages` longtext NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `11course1i`
--

INSERT INTO `11course1i` (`id`, `time`, `date`, `class`, `messages`) VALUES
(1, '09:43 AM', '16-02-09', 8, 'your class will be held on next monday');

-- --------------------------------------------------------

--
-- Table structure for table `11course1l`
--

CREATE TABLE IF NOT EXISTS `11course1l` (
`id` int(11) NOT NULL,
  `time` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `class` int(11) NOT NULL,
  `file1` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `11course1l`
--

INSERT INTO `11course1l` (`id`, `time`, `date`, `class`, `file1`) VALUES
(4, '12:15 PM', '16-02-10', 1, 'uploads/-432179871IP-address-1.ppt'),
(5, '12:16 PM', '16-02-10', 2, 'uploads/-1075849038Lecture 1 (Keyboard).ppt'),
(6, '12:16 PM', '16-02-10', 3, 'uploads/-522137553Lecture 2 (Mouse) - Copy.ppt'),
(7, '12:16 PM', '16-02-10', 4, 'uploads/-1172158872Lecture 3 (Monitor) - Copy.ppt'),
(8, '12:16 PM', '16-02-10', 5, 'uploads/-1119520083Lecture 4 (Printer) - Copy.ppt'),
(9, '12:17 PM', '16-02-10', 6, 'uploads/-332086770Lecture 5 (Scanner).ppt');

-- --------------------------------------------------------

--
-- Table structure for table `11course1r`
--

CREATE TABLE IF NOT EXISTS `11course1r` (
`id` int(11) NOT NULL,
  `time` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `class` int(11) NOT NULL,
  `messages2` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `11course1r`
--

INSERT INTO `11course1r` (`id`, `time`, `date`, `class`, `messages2`) VALUES
(1, '19:02 PM', '16-02-09', 1, 'teach yourself'),
(2, '00:51 AM', '16-02-10', 1, 'Ansi c by balagurusamy');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
`id` int(11) NOT NULL,
  `login_id` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `security` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `login_id`, `password`, `security`) VALUES
(2, 'osman', 'osman120', '120');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
`id` int(11) NOT NULL,
  `login_id` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `roll` int(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `semester` int(4) NOT NULL,
  `approve` tinyint(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `login_id`, `password`, `name`, `roll`, `email`, `mobile`, `semester`, `approve`) VALUES
(1, '', '87987', 'rakhi', 1108049, 'anusuyapaul45@gmail.', '', 32, 1),
(29, 'osman', 'osman120', 'kiron osman', 1208024, 'kironosmancse120@gma', '01757786118', 11, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `11course1`
--
ALTER TABLE `11course1`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `11course1g`
--
ALTER TABLE `11course1g`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `11course1i`
--
ALTER TABLE `11course1i`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `11course1l`
--
ALTER TABLE `11course1l`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `11course1r`
--
ALTER TABLE `11course1r`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `11course1`
--
ALTER TABLE `11course1`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `11course1g`
--
ALTER TABLE `11course1g`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `11course1i`
--
ALTER TABLE `11course1i`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `11course1l`
--
ALTER TABLE `11course1l`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `11course1r`
--
ALTER TABLE `11course1r`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
