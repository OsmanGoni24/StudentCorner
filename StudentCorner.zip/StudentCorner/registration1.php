<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title>    
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="registration.php">
                        BACK
                    </a>
                </li>
                
            </ul>
        </div>
        <div id="header">
             <div id="title">
                    Student's corner
             </div>
        </div>
        <div id="body">
           
            <div id="message">
            <p> Data inserted successfully.</p>  
            </div>
        </div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>