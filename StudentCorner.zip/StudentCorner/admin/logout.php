

<?php

if(isset($_SESSION['aid'])){
	unset($_SESSION['aid']);
	session_destroy();
	echo "<script>location.href='../index.php'</script>";

}
echo "<script>location.href='../index.php'</script>";



?>