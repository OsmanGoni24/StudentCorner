<?php session_start();?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title> 
<style>
#content{
height:200px;
}
#roll{
display:block;
background-color:#8b0000;
color:#ffebcd;
text-align:center;
height:50px; 
width:170px;
margin-left:600px;
margin-top:70px;
font-size:20px;
}

</style>	
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="request.php">
                        BACK
                    </a>
                </li>
               
            </ul>
        </div>
        <div id="title">
             <div id="title4">
                    Admin Panel
             </div>
        </div>
        <div id="content">
          <?php 
          $con=mysql_connect('localhost','root','');
          if(!$con){
            echo 'mysql connection error'.mysql_error();
            
          }
          $db=mysql_select_db('student_corner');
          if(!$db){
            echo 'mysql selection error'.mysql_error();
          }
          $id=$_GET['id'];
          $approve=1;
		  $sql3=mysql_query("select * from student where id='$id'");
		  $data=mysql_fetch_array($sql3);
		  $roll=$data['roll'];
		  $sql4=mysql_query("select * from student where roll='$roll' and approve='$approve'");
		  $check=mysql_num_rows($sql4);
		  if($check>0)
		  {
		  echo "<script> alert('Already exist this roll')</script>";
		  echo "<script> location.href='request.php'</script>";
		  }
		  else{
		  
          $sql=mysql_query("update student set approve=1 where id=$id");
          $sql2=mysql_query("select * from student where roll=$roll");
          
          $data=mysql_fetch_array($sql2);
          $roll=$data['roll'];
		  $to=$data['email'];
		  $subject='registration successful';
		  $headers='admin12@gmail.com';
		  $message='thanks for registration';
		  $success=mail($to,$subject,$message,$headers);
		  echo "<div id='roll'>";
          if(!$sql){
            echo "The roll ".$roll." is not approved";
          }
          else{
            echo"The roll ".$roll." is approved";
          }
		  echo "</div>";
     }		  
          ?>
        </div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>