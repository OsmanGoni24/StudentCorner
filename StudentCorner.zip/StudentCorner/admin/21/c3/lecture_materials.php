<?php session_start();
if(!isset($_SESSION['aid'])){
echo "<script>location.href='../../../index.php'</script>";
}
else {
echo " ";
}
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title>    
    <style>
	#content p{
	   font-weight: bold;
       text-align: center;
	}
    
    
	</style>
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
			    <li>
                    <a href="index.php">
                       HOME
                    </a>
                </li>
				<li>
                    <a href="lecture_materials.php">
                      LECTURE MATERIALS
                    </a>
                </li>
				
				<li>
                    <a href="referencebook.php">
                      REFERENCE BOOK
                    </a>
                </li>
                <li>
                    <a href="logout.php">
                      LOGOUT
                    </a>
                </li>
				
            </ul>
        </div>
        <div id="title">
             <div id="title4">
              student's corner
             </div>
             
            </div>
             <img src='capture3.PNG' style='margin-left:auto;margin-right:auto;display:block;'>
             <div id="title2">
               Admin Panel
            </div>
           </div>
            <div id="title3">
               </br>
                </div>
                <div id='date'>
                <script lang="javascript">
                var today=new Date();
                document.write(today);
                </script>
                </div>
                
        </div>
        <div id="content">
		<div id="title6">
                update Lecture Materials for the students 11 course 1
            </div>
          <form method='post' action='lecture_upload.php' enctype='multipart/form-data'>
		  <table border='0' align='center'>
          <tr><td>class</td><td><input type="text" name="class" placeholder="type the number of class"></td></tr>
		  
		  <tr><td></td><td><p>Upload File&nbsp;&nbsp;<img src="Capture5.PNG"></p></td></tr>
		  <tr><td>File</td><td><input type='file' name='file'  size='80'> </td></tr>
		  
		  <tr><td></td><td><input type='submit' name='submit' value='post'></td></tr>
		  </table>
		  </form>
        </div>
        <div id="footer">
            <div id="copy">
                &copy;&nbsp;copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>