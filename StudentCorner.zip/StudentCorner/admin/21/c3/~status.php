
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
    <link rel="stylesheet" href=
    "http://cdnjs.cloudflare.com/ajax/libs/font-awsome/4.4.0/css/font-awsome.min.css">
	<title>student's corner</title>
    <style>#content{height: 900px;}</style>    
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="request.php">
                        STUDENT REQUEST
                    </a>
                </li>
                <li>
                    <a href="status.php">
                        UPDATE STATUS
                    </a>
                </li>
                <li>
                    <a href="file.php">
                        UPDATE FILE
                    </a>
                </li>
            </ul>
        </div>
        <div id="title">
             <div id="title4">
             Student's Corner
             </div>
        </div>
        <div id="title2">
               Admin Panel
            </div>
            <div id="title3">
                </br>
                </div>
                <div id='date'>
                </br>
                </div>
                <div id="title5">
                Update Status
            </div>
        <div id="content">
          <div id='box'>
          <form  method="post"action="status_process.php" enctype="multipart/form-data">
          <table border='0' align='center'>
          <tr><td>Session</td><td><input type="text" placeholder="type session" name="session"></td></tr>
          <tr><td>Status</td><td><textarea name="messages" cols="50"rows="10" style="display:block; border: 1px solid #000;"></textarea></td></tr>
          <tr><td></td><td><input type="submit" name="submit" value="post" style="background-color:#336699;width:55px;"></td> </tr>
          </table>
          </form>                                                                                                          
          </div>
        </div>
        

        <div id='footer'>
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>