<?php session_start();
if(!isset($_SESSION['aid'])){
echo "<script>location.href='../../index.php'></script>";
}
else{
echo "";
}
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title>    
    <style>#content{margin-top:20px;margin-left:50px;height:200px;}
    
    
#instruction{
float:right;
}
#instruction p{
color:#778899;
}
#course{
float:left;
}	
.course_list ul li a{
text-decoration:none;
font-size:20px;
color:#778899;
} 
.course_list ul li a:hover{

color:#000;
} 
</style>
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>   
				<li><a href='logout.php'>logout</a></li>    
            </ul>
        </div>
        <div id="title">
             <div id="title4">
              student's corner
             </div>
		</div>
		<img src='capture3.PNG' style='margin-left:auto;margin-right:auto;display:block;'>
             <div id="title2">
               Admin Panel
             </div>    
		    
		
            <div id="title3">
                </br>
                </div>
                <div id='date'>
                <script lang="javascript">
                var today=new Date();
                document.write(today);
                </script>
                </div>
                
        
        <div id="content">
		<div id='course'>
		<div class='course_name'>
          <h2>Course Name</h2></div>
          <div class="course_list">
          <ul type='disc'>
		  <li><a href='c1/index.php'>Course 1</a></li>
		  <li><a href='c1/index.php'>Course 2</a></li>
		  <li><a href='c1/index.php'>Course 3</a></li>
		  <li><a href='c1/index.php'>Course 4</a></li>
          <ul>
          
        </div>
		</div>
        
		<div id='right_bar'>
		 <h2>Instruction</h2>
		 <p>please select a course name</p>
		</div>
		</div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>