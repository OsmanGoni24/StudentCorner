<?php session_start();
          $con=mysql_connect('localhost','root','');
          if(!$con){
            echo 'mysql connection error'.mysql_error();
            
          }
          
          $db=mysql_select_db('student_corner');
          if(!$db){
            echo 'mysql selection error'.mysql_error();
          }
		  $dt=new DateTime('now',new DateTimeZone('Asia/Dhaka'));
     $time=$dt->format('H:i A');
     $date=$dt->format('y-m-d');
          $class=$_POST['class'];
        
        
          $messages2=$_POST['messages2'];

		  $sql=mysql_query("insert into 11course1r values('','$time','$date','$class','$messages2')");
		  if($sql){
		      echo "<script>alert('updated successfully')</script>";
              echo "<script>location.href='referencebook.php'</script>";
		  }
		 else{
		  echo "data are not uploaded successfully".mysql_error();
          
          
        }
        
     ?>   


