<?php session_start();
          $con=mysql_connect('localhost','root','');
          if(!$con){
            echo 'mysql connection error'.mysql_error();
            
          }
          $dir="uploads/";
		  $rand=rand(0,999999999999999);
		  $file=$_FILES['file2']['name'];
		  $file2=$dir.$rand.$file;
		  
		 
          move_uploaded_file($_FILES['file2']['tmp_name'],"../../../$file2");
          
          $db=mysql_select_db('student_corner');
          if(!$db){
            echo 'mysql selection error'.mysql_error();
          }
		  $dt=new DateTime('now',new DateTimeZone('Asia/Dhaka'));
     $time=$dt->format('H:i A');
     $date=$dt->format('y-m-d');
          $class=$_POST['class'];
		  $exam=$_POST['exam'];
        $sql3=mysql_query("select * from 11course1g where  class=$class");
		 $check=mysql_num_rows($sql3);
		 if($check>0){
		 echo "<script>alert('already exist messages for this class')</script>";
		 echo "<script>location.href='gradesheet.php'</script>";
		 }
          else{
		  $sql=mysql_query("insert into 11course1g values('','$time','$date','$class','$exam','$file2')");
		  if($sql){
		      echo "<script>alert('updated successfully')</script>";
              echo "<script>location.href='gradesheet.php'</script>";
		  }
		 else{
		  echo "data are not uploaded successfully".mysql_error();
          
          
        }
		}
        
     ?>   


