<?php session_start();
          $con=mysql_connect('localhost','root','');
          if(!$con){
            echo 'mysql connection error'.mysql_error();
            
          }
          $dir="uploads/";
		  $rand=rand(0,999999999999999);
		  $file=$_FILES['file']['name'];
		  $file1=$dir.$rand.$file;
		  move_uploaded_file($_FILES['file']['tmp_name'],"../../../$file1");
		 
         
          $db=mysql_select_db('student_corner');
          if(!$db){
            echo 'mysql selection error'.mysql_error();
          }
		  $dt=new DateTime('now',new DateTimeZone('Asia/Dhaka'));
     $time=$dt->format('H:i A');
     $date=$dt->format('y-m-d');
          $class=$_POST['class'];
          
        $sql3=mysql_query("select * from 11course1l where  class=$class");
		 $check=mysql_num_rows($sql3);
		 if($check>0){
		 echo "already exist messages for this class";
		 }
		 else{
		  $sql=mysql_query("insert into 11course1l values('','$time','$date','$class','$file1')");
		  if($sql){
		      echo "<script>alert('updated successfully')</script>";
              echo "<script>location.href='lecture_materials.php'</script>";
		  }
		 else{
		  echo "data are not uploaded successfully".mysql_error();
          
          
        }
		}
        
     ?>   


