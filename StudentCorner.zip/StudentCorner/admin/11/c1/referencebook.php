<?php session_start();
if(!isset($_SESSION['aid'])){
echo "<script>location.href='../../../index.php'</script>";
}
else {
echo " ";
}
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title>    
    <style>
	#content p{
	   font-weight: bold;
       text-align: center;
	}
    
    
	</style>
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
			   <li>
                    <a href="index.php">
                       HOME
                    </a>
                </li>
				<li>
                    <a href="lecture_materials.php">
                      LECTURE MATERIALS
                    </a>
                </li>
			
				<li>
                    <a href="referencebook.php">
                      REFERENCE BOOK
                    </a>
                </li>
                <li>
                    <a href="logout.php">
                    LOGOUT
                    </a>
                </li>
				
            </ul>
        </div>
        <div id="title">
             <div id="title4">
              student's corner
             </div>
             
            </div>
             <img src='capture3.PNG' style='margin-left:auto;margin-right:auto;display:block;'>
             <div id="title2">
               Admin Panel
            </div>
           </div>
            <div id="title3">
                Student Management System</br>
                </div>
                <div id='date'>
                <script lang="javascript">
                var today=new Date();
                document.write(today);
                </script>
                </div>
                
        </div>
        <div id="content">
		<div id="title6">
                update reference book for semester 11 course 1
            </div>
          <form method='post' action='book_upload.php' enctype='multipart/form-data'>
		  <table border='0' align='center'>
          <tr><td>class</td><td><input type="text" name="class" placeholder="type the number of class"></td></tr>
		  <tr><td></td><td><p>reference book</p></td></tr>
		  <tr><td>Books</td><td><textarea cols=40 rows=10 placeholder='type books name here' name='messages2' style='display:block;border=2px solid #000'></textarea> </td></tr>
		  <tr><td></td><td><input type='submit' name='submit' value='post'></td></tr>
		  </table>
		  </form>
        </div>
        <div id="footer">
            <div id="copy">
                &copy;&nbsp;copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>