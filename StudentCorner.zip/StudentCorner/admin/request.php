<?php session_start();

?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title>    
    <style>#content{margin-top:20px; height:auto; margin-bottom:20px}
	</style>
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="request.php">
                        STUDENT REQUEST
                    </a>
                </li>
                <li>
                    <a href="">
                        SEMESTER
                    </a>
					<ul>
					 <li><a href='11/index.php'>11</a></li>
					 <li><a href='12/index.php'>12</a></li>
					 <li><a href='21/index.php'>21</a></li>
					 <li><a href='22/index.php'>22</a></li>
					 
					</ul>
                
                </li>
				<li><a href='logout.php'>LOGOUT</a></li>
            </ul>
        </div>
        <div id="title">
             <div id="title4">
              student's corner
             </div>
		</div>
		<div id='pic'><img src='capture3.PNG' style="margin-left:auto;margin-right:auto;display:block;"></div>
             <div id="title2">
               Admin Panel
            </div>
			
            <div id="title3">
                </br>
                </div>
                
                <div id='date'>
                <script lang="javascript">
                var today=new Date();
                document.write(today);
                </script></br>
                </div>
               
                <div id="title5">
                Student's request
            </div>
        
        <div id="content">
          <?php
          $con=mysql_connect('localhost','root','');
          if(!$con){
            echo 'mysql connection error'.mysql_error();
            
          }
          $db=mysql_select_db('student_corner');
          if(!$db){
            echo 'mysql selection error'.mysql_error();
          }
          $sql=mysql_query('select * from student where approve=0');
          if(mysql_num_rows($sql)>0){
           echo "<div class='details'><form method='post' enctype='multipart/form-data' action='approve_process.php'>";
           echo "<table border='1' align='center' cellpadding='6' cellspacing='0'>";
           
          echo "<tr><th>FULL  NAME</th><th>USER NAME</th><th>ROLL</th><th>EMAIL</th><th>MOBILE</th><th>SEMESTER</th><th colspan='2'>STATUS</tr>";
          while($data=mysql_fetch_array($sql)){
          
          $id=$data['id'];
          $user_name=$data['login_id'];
          $password=$data['password'];
          $name=$data['name'];
          $roll=$data['roll'];
          $email=$data['email'];
          $mobile=$data['mobile'];
          $semester=$data['semester'];
          
          echo "<tr><td>$name</td><td>$user_name</td><td>$roll</td><td>$email</td><td>$mobile</td><td>$semester</td><td><a href='approve_process.php?id=$id'>Approve</a></td><td><a href='delete_process.php?id=$id'>Delete</a></td></tr>";
          }
          echo "</form></table></div>";
           }
           else{
            echo "<div id='alert'>No request found</div>";
           }
          ?>
        </div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>