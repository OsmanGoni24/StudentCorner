
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
    <link rel="stylesheet" href=
    "http://cdnjs.cloudflare.com/ajax/libs/font-awsome/4.4.0/css/font-awsome.min.css">
	<title>student's corner</title>
    <style>#content{
       height: auto;
       font-family: arial;
       margin-top:30px;}
    #file input[name='file']{
       border-left-color: #778899;
    border-top-color: #778899;
    text-align: center;
    height:30px;  
    }
    #file input[name='session']{
       border-left-color: #778899;
    border-top-color: #778899;
    text-align: center;
    height:30px;  
    }
    #file input[name="submit"]{
    }
    #file p{margin-left: 300px;}
    </style>    
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="request.php">
                        STUDENT REQUEST
                    </a>
                </li>
                <li>
                    <a href="status.php">
                        UPDATE STATUS
                    </a>
                </li>
                <li>
                    <a href="file.php">
                        UPDATE FILE
                    </a>
                </li>
            </ul>
        </div>
        <div id="title">
             <div id="title4">
             Student's Corner
             </div>
        </div>
        <div id="title2">
               Admin Panel
            </div>
            <div id="title3">
               </br>
                </div>
                <div id='date'>
                <script lang="javascript">
                var today=new Date();
                document.write(today);
                </script></br>
                </div>
                <div id="title5">
                Update File</br>
                <img src="Capture.PNG" style="image;">
            </div>
            
        <div id="content">
            <div id="file">
            <form enctype="multipart/form-data"action="upload_file.php"method="post"> 
                <table border='0' align='center'>
                 <tr><td>Session</td><td><input type="text" placeholder="type session" name="session"></td></tr>
                 <tr><td>File</td><td><input name="file" type="file"id="file"size="80"><br /></td></tr>
                 <tr><td></td><td><input type="submit" name="submit"id="u_button"value="upload the File"></td></tr>
                 </table>
               </form>  
                    
                
            </div>
        </div>
    </div>
    

        <div id='footer'>
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>