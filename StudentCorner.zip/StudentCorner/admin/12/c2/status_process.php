<?php session_start();
        $status=$_POST['messages'];
        $session=$_POST['session'];
        $con=mysql_connect('localhost','root','');
        if(!$con){
            echo "error".mysql_error();
        }
        $db=mysql_select_db('student_corner');
        if(!$db)
        {
            echo "database selection error".mysql_error();
        }
        $sql=mysql_query("insert into status values('','$session','$status') ");
        if(!$sql){
            echo "database selection error".mysql_error();
        }
        else{
        echo "<script>alert('updated successfully')</script>";
        echo "<script>location.href='status.php'</script>";
            }
        ?>