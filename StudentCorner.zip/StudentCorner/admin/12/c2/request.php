<?php session_start();?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title>    
    <style>#content{margin-top:200px;}</style>
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="request.php">
                        STUDENT REQUEST
                    </a>
                </li>
                <li>
                    <a href="status.php">
                        UPDATE STATUS
                    </a>
                </li>
                <li>
                    <a href="file.php">
                        UPDATE FILE
                    </a>
                </li>
            </ul>
        </div>
        <div id="title">
             <div id="title4">
              student's corner
             </div>
             <div id="title2">
               Admin Panel
            </div>
            <div id="title3">
                Student Management System</br>
                </div>
                <div id='date'>
                </br>
                </div>
                <div id="title5">
                Student's request
            </div>
        </div>
        <div id="content">
          <?php
          $con=mysql_connect('localhost','root','');
          if(!$con){
            echo 'mysql connection error'.mysql_error();
            
          }
          $db=mysql_select_db('student_corner');
          if(!$db){
            echo 'mysql selection error'.mysql_error();
          }
          $sql=mysql_query('select * from student where approve=0');
          if(mysql_num_rows($sql)>0){
           echo "<div class='details'><form method='post' enctype='multipart/form-data' action='approve_process.php'>";
           echo "<table border='1' align='center' cellpadding='6' cellspacing='0'>";
           
          echo "<tr><th>FULL  NAME</th><th>USER NAME</th><th>ROLL</th><th>EMAIL</th><th>MOBILE</th><th>SEMESTER</th><th>STATUS</tr>";
          while($data=mysql_fetch_array($sql)){
          
          $id=$data['id'];
          $user_name=$data['login_id'];
          $password=$data['password'];
          $name=$data['name'];
          $roll=$data['roll'];
          $email=$data['email'];
          $mobile=$data['mobile'];
          $semester=$data['semester'];
          
          echo "<tr><td>$name</td><td>$user_name</td><td>$roll</td><td>$email</td><td>$mobile</td><td>$semester</td><td><a href='approve_process.php?id=$id'>Approve</a></td></tr>";
          }
          echo "</form></table></div>";
           }
           else{
            echo "<font color='red'>"."no request found"."</font>";
           }
          ?>
        </div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>