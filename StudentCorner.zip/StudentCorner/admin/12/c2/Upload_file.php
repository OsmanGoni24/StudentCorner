<?php session_start();
$session=$_POST[session];

move_uploaded_file($_FILES['file']['tmp_name'],"uploads/".$_FILES['file']['name']);
move_uploaded_file($_FILES['file']['tmp_name'],"student/uploads/".$_FILES['file']['name']);

$file="uploads/".$_FILES['file']['name'];

$con=mysql_connect('localhost','root','');
if(!$con){
    echo "mysql connection error".mysql_error();
}
$db=mysql_select_db('student_corner');
if(!$db)
{
    echo 'database selection error'.mysql_error();
}
$sql=mysql_query("insert into uploadfile values ('','$session','$file')");
if(!$sql)
{
    echo "run time error".mysql_error();
}
else
{
   echo "<script>alert('succesfully updated')</script>";
   echo "<script>location.href='file.php'</script>";
   $sql2=mysql_query('select file from uploadfile order by id desc');
   if (!$sql2){
    echo "run time error".mysql_error();
   }
   else{
    $data=mysql_fetch_array($sql2);
    $file=$data['file'];
    echo "$file";
    echo "<br>";
    
   }
}
?>