<?php session_start();?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title> 
<style>
#content{
height:200px;
}
#roll{
display:block;
background-color:#8b0000;
color:#ffebcd;
text-align:center;
height:50px; 
width:170px;
margin-left:600px;
margin-top:70px;
font-size:20px;
}

</style>	
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="request.php">
                        BACK
                    </a>
                </li>
               
            </ul>
        </div>
        <div id="title">
             <div id="title4">
                    Admin Panel
             </div>
        </div>
        <div id="content">
          <?php 
          $con=mysql_connect('localhost','root','');
          if(!$con){
            echo 'mysql connection error'.mysql_error();
            
          }
          $db=mysql_select_db('student_corner');
          if(!$db){
            echo 'mysql selection error'.mysql_error();
          }
          $id=$_GET['id'];
         
		  $sql3=mysql_query("delete from student where id='$id'");
		  
		 
		  
		 
		  if($sql3)
		  {
		  echo "<script>alert('The roll is deleted')</script>";
		  echo "<script> location.href='request.php'</script>";
		  }
		  
		 		  
          ?>
        </div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>