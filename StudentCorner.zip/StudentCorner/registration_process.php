<?php
$con=mysql_connect('localhost','root','');
if(!$con){
    echo "Error".mysql_error();
}
$db=mysql_select_db("Student_corner");
if(!$db)
{
    echo "Database selection error".mysql_error();
}
$login_id=$_POST['user_name'];
$password=$_POST['password'];
$name=$_POST['name'];
$roll=$_POST['roll'];
$email=$_POST['email'];
$mobile=$_POST['mobile_no'];
$semester=$_POST['semester'];
$approve=0;

$sr=mysql_query("select * from student where roll='$roll' and approve='1'");
$check=mysql_num_rows($sr);
if($check>0){
    header("Location:registration2.php");
}
else{

    $sql=mysql_query("insert into student values('','$login_id','$password','$name','$roll','$email','$mobile','$semester','$approve')");
    if(!$sql){
        echo "run time error ".mysql_error();
        }
       else{
        header("Location:registration1.php");
       }
   }

?>