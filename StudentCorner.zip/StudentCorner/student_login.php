<?php
session_start();
$login_id=$_POST['user_name'];
$password=$_POST['password'];
$semester=$_POST['semester'];
$approve=1;
$con=mysql_connect('localhost','root','');
if(!$con)
{
    print "Error".mysql_error();
}
$db=mysql_select_db('student_corner');
if(!$db){
 print "Error".mysql_error();   
 }
 
		$sql=mysql_query("SELECT * FROM `student` WHERE  login_id='$login_id' and password='$password' and semester='$semester' and approve='$approve'");
		if($sql){
		$count=mysql_num_rows($sql);
		
		$id=mysql_fetch_array($sql);
		$_SESSION['sid']=$id['id'];
		if($count>0 && $semester==11){
			print "<script>location.href='student/11/index.php'</script>";
		}
			if($count>0 && $semester==12){
			print "<script>location.href='student/12/index.php'</script>";
		}
			if($count>0 && $semester==21){
			print "<script>location.href='student/21/index.php'</script>";
		}
			if($count>0 && $semester==22){
			print "<script>location.href='student/22/index.php'</script>";
		}
		if($count>0 && $semester==31){
			print "<script>location.href='student/31/index.php'</script>";
		}
		if($count>0 && $semester==32){
			print "<script>location.href='student/32/index.php'</script>";
		}
		if($count>0 && $semester==41){
			print "<script>location.href='student/41/index.php'</script>";
		}
		if($count>0 && $semester==42){
			print "<script>location.href='student/41/index.php'</script>";
		}
		else{
			echo "<script>alert('you are not yet student now')</script>";
			echo "<script>location.href='index.php'</script>";
		}
 }
 else{
 echo "sql error".mysql_error();
 }
 
 
 ?>