<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="TomaHawk / EDGE" />
    <link rel="stylesheet" type="text/css" href="css.css"/>
	<title>student's corner</title>
<style>

</style>    
</head>

<body>
    <div id="wrapper">
        <div id="menu">
            <ul>
                <li>
                    <a href="index.php">
                        LOGIN
                    </a>
                </li>
                <li>
                    <a href="instruction.php">
                        INSTRUCTION
                    </a>
                </li>
            </ul>
        </div>
        <div id="header">
             <div id="title">
                    Student's corner
             </div>
        </div>
        <div id="body">
		<div id='pic'>
		<img src='capture3.PNG'style="margin-left:auto;margin-right:auto;display:block;margin-top:40px;">
		</div>
            <div id="title2">
               Student's Corner
            </div>
            <div id="slogan">
                </br>
                </div>
                <div id='date'>
                <script lang="javascript">
                var today=new Date();
                document.write(today);
                </script></br>
                </div>
                
			<div id='content'>
			<div id="title6">
                Student Registration Panel
            </div>
            <div id="log">
                <form method="post" action="registration_process.php">
                <table border='0' cellspacing='0' cellpadding='11' align='center'>
                    <tr>
                        <td>
                            Login ID:
                        </td>
                        <td>
                            <input type="text" placeholder="username" name="user_name"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                          Login Password:
                        </td>
                        <td>
                            <input type="password" placeholder="type your password" name="password"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Name
                        </td>
                        <td>
                            <input type="text" placeholder="full name" name="name"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Roll
                        </td>
                        <td>
                            <input type="text" placeholder="class roll" name="roll"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Email
                        </td>
                        <td>
                            <input type="text" placeholder="email" name="email"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Mobile no
                        </td>
                        <td>
                            <input type="text" placeholder="mobile no" name="mobile_no"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Semester
                        </td>
                        <td>
                            <input type="text" placeholder="semester code" name="semester"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                        </td>
                        
                        <td align='right'>
                            <input type="submit"value='save' name="submit"/>
                        </td>
                    </tr>
                </table>
                </form>
            </div>
        </div>
		</div>
        <div id="footer">
            <div id="copy">
                copyright protected by CSE department,Comilla university-
            </div>
        </div>

    </div>


</body>
</html>