<?php
session_start();
$login_id=$_POST['user_name'];
$password=$_POST['password'];
$semester=$_POST['semester'];
$approve=1;
$con=mysql_connect('localhost','root','');
if(!$con)
{
    print "Error".mysql_error();
}
$db=mysql_select_db('student_corner');
if(!$db){
 print "Error".mysql_error();   
 }
 
		$sql=mysql_query("SELECT * FROM `student` WHERE  login_id='$login_id' and password='$password' and semester='$semester' and approve='$approve'");
		if($sql){
		$count=mysql_num_rows($sql);
		if($count>0){
			print "<script>location.href='admin/request.php'</script>";
		}
		
		else{
			print "Not admin ";
		}
 }
 else{
 echo "sql error".mysql_error();
 }
 
 
 ?>